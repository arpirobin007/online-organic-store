<div class="col-sm-3">
					<div class="left-sidebar">
						<h2>cPanel</h2>				 
    	                   <div class="list-group">
                               <a href="admin.php" class="list-group-item">Products <span class="products-admin-badge pull-right text-info">0</span></a>   
                               <a href="order.php" class="list-group-item">Orders <span class="order-admin-badge pull-right text-danger">0</span></a> 
                               <a href="admincategory.php" class="list-group-item">Category <span class="category-admin-badge pull-right text-warning">0</span></a>                                                                                                                           
                            </div>
                            <div class="list-group">
                               <a href="logout.php" class="list-group-item active">Logout</a>
                            </div>
                        </div>
                        </div>